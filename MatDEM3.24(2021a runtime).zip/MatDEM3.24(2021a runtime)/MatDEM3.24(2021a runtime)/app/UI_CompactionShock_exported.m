classdef UI_CompactionShock_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        WinMain                         matlab.ui.Figure
        Label_statusBar                 matlab.ui.control.Label
        TextArea_Message                matlab.ui.control.TextArea
        Button_Run                      matlab.ui.control.Button
        EditField_CommandLine           matlab.ui.control.EditField
        Label                           matlab.ui.control.Label
        Steps                           matlab.ui.container.TabGroup
        Home                            matlab.ui.container.Tab
        GIFLabel                        matlab.ui.control.Label
        Image2                          matlab.ui.control.Image
        V10Label                        matlab.ui.control.Label
        Image1                          matlab.ui.control.Image
        Step1                           matlab.ui.container.Tab
        EditField_modelName             matlab.ui.control.EditField
        Label_10                        matlab.ui.control.Label
        Panel_3                         matlab.ui.container.Panel
        Label_porosity                  matlab.ui.control.Label
        Button_gravitySedimentAndStandardBalance  matlab.ui.control.Button
        CheckBox_isCement               matlab.ui.control.CheckBox
        CheckBox_uniformGRate           matlab.ui.control.CheckBox
        CheckBox_resetStatusBeforeDrop  matlab.ui.control.CheckBox
        Panel_2                         matlab.ui.container.Panel
        Label_22                        matlab.ui.control.Label
        EditField_friction              matlab.ui.control.NumericEditField
        Label_6                         matlab.ui.control.Label
        EditField_materialMatrix        matlab.ui.control.EditField
        Label_8                         matlab.ui.control.Label
        Panel                           matlab.ui.container.Panel
        Label_particleNumber            matlab.ui.control.Label
        EditField_PSDtype               matlab.ui.control.NumericEditField
        Label_7                         matlab.ui.control.Label
        EditField_sampleHrate0          matlab.ui.control.NumericEditField
        Label_5                         matlab.ui.control.Label
        EditField_sampleL               matlab.ui.control.NumericEditField
        mLabel_2                        matlab.ui.control.Label
        EditField_sampleW               matlab.ui.control.NumericEditField
        mLabel                          matlab.ui.control.Label
        EditField_particleDensity       matlab.ui.control.NumericEditField
        kgm3Label                       matlab.ui.control.Label
        EditField_totalM                matlab.ui.control.NumericEditField
        kgLabel                         matlab.ui.control.Label
        EditField_PSDmatrix             matlab.ui.control.EditField
        Label_4                         matlab.ui.control.Label
        EditField_rangeNumber           matlab.ui.control.NumericEditField
        Label_3                         matlab.ui.control.Label
        Button_showPSDcurve             matlab.ui.control.Button
        Button_buildInitialModel        matlab.ui.control.Button
        EditField_seedID                matlab.ui.control.NumericEditField
        Label_2                         matlab.ui.control.Label
        Step2                           matlab.ui.container.Tab
        Panel_7                         matlab.ui.container.Panel
        EditField_additionalStandardRate  matlab.ui.control.NumericEditField
        Label_21                        matlab.ui.control.Label
        EditField_aFS0rate              matlab.ui.control.NumericEditField
        Label_14                        matlab.ui.control.Label
        EditField_aBFrate               matlab.ui.control.NumericEditField
        Label_13                        matlab.ui.control.Label
        CheckBox_connectSample          matlab.ui.control.CheckBox
        Button_startShock               matlab.ui.control.Button
        EditField_mVisrate              matlab.ui.control.NumericEditField
        Label_16                        matlab.ui.control.Label
        EditField_aMUprate              matlab.ui.control.NumericEditField
        Label_15                        matlab.ui.control.Label
        Panel_6                         matlab.ui.container.Panel
        Button_showReceiver             matlab.ui.control.Button
        EditField_receiverNumber        matlab.ui.control.NumericEditField
        Label_17                        matlab.ui.control.Label
        Panel_5                         matlab.ui.container.Panel
        EditField_totalCircle           matlab.ui.control.NumericEditField
        Label_12                        matlab.ui.control.Label
        EditField_totalSecond           matlab.ui.control.NumericEditField
        sLabel                          matlab.ui.control.Label
        EditField_shockF                matlab.ui.control.NumericEditField
        HzLabel                         matlab.ui.control.Label
        EditField_shockA                matlab.ui.control.NumericEditField
        mLabel_4                        matlab.ui.control.Label
        EditField_staticPressure        matlab.ui.control.NumericEditField
        PaLabel                         matlab.ui.control.Label
        Button_showWaveCurve            matlab.ui.control.Button
        CheckBox_isCompressiveWave      matlab.ui.control.CheckBox
        Panel_4                         matlab.ui.container.Panel
        Button_cutSample                matlab.ui.control.Button
        EditField_cutHeight             matlab.ui.control.NumericEditField
        mLabel_3                        matlab.ui.control.Label
        Button_loadModel                matlab.ui.control.Button
        EditField_modelName2            matlab.ui.control.EditField
        Label_11                        matlab.ui.control.Label
        dataCenter                      matlab.ui.container.Tab
        GIFLabel_2                      matlab.ui.control.Label
        Button_2                        matlab.ui.control.Button
        Button                          matlab.ui.control.Button
        Button_openDataFile             matlab.ui.control.Button
        EditField_dataFile              matlab.ui.control.EditField
        Label_20                        matlab.ui.control.Label
        Tab                             matlab.ui.container.Tab
        MatDEMforummatdemcomhttpmatdemcomLabel  matlab.ui.control.Label
        UIAxes_PlottingArea             matlab.ui.control.UIAxes
    end

    
    properties (Access = public)
        Settings;
        Box;
        DataCenter;
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.Settings=[];
            app.Box=[];
            app.DataCenter=[];
            app.Settings.PlottingAreaParentHandle=app.WinMain;
            app.Settings.PlottingAreaParentPosition=app.WinMain.Position;
            app.Settings.PlottingAreaHandle=app.UIAxes_PlottingArea;
            app.Settings.PlottingAreaPosition=app.UIAxes_PlottingArea.Position;
            app.Settings.OutputFocus=app.TextArea_Message;
            app.Image1.ImageSource='Resources/CompactionShock1.jpg';
            app.Image2.ImageSource='Resources/CompactionShock3.jpg';
            setappdata(0,'app',app);
            setappdata(0,'CurrentWindow',1);
        end

        % Button pushed function: Button_Run
        function Button_RunPushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            app.TextArea_Message.Value=[app.EditField_CommandLine.Value;app.TextArea_Message.Value];
            try
                eval(app.EditField_CommandLine.Value);
            catch ME
                app.TextArea_Message.Value=[ME.identifier;app.TextArea_Message.Value];
            end
            app.EditField_CommandLine.Value='';
            app.Box=B;
            app.DataCenter=d;
        end

        % Close request function: WinMain
        function WinMainCloseRequest(app, event)
            delete(app)
            try
                rmappdata(0,'app');
                rmappdata(0,'CurrentWindow');
            catch
                %不做任何处理
            end
        end

        % Button pushed function: Button_buildInitialModel
        function Button_buildInitialModelPushed(app, event)
            seedId=app.EditField_seedID.Value;
            rangeNum=app.EditField_rangeNumber.Value;
            totalM=app.EditField_totalM.Value;
            grainDensity=app.EditField_particleDensity.Value;
            moNum='auto';%divided into 'moNum' size groups (childModel),0~10
            rate='auto';%automatical balance rate in B.gravitySediment
            isCement=app.CheckBox_isCement.Value;
            
            hRate=app.EditField_sampleHrate0.Value;
            friction=app.EditField_friction.Value;
            isUniformGRate=app.CheckBox_uniformGRate.Value;
            grainSizeDistribution=str2num(app.EditField_PSDmatrix.Value);
            gradingCurveType=app.EditField_PSDtype.Value;

            sampleW=app.EditField_sampleW.Value;
            sampleL=app.EditField_sampleL.Value;
            is2D=0;
            if sampleL==0
                is2D=1;
            end
            
            %@@@@@@@@@@@@@@@@@@the following is copied from the code

            %--------------step1: initializing Box model------------
            fs.chooseGPU();
            fs.randSeed(seedId);%change it to get a different model
            grainSizeDistribution=grainSizeDistribution(end-rangeNum+1:end,:);
            %determine the grain radius (grainR) according to the above data
            grainR=mfs.getGradationDiameter(grainSizeDistribution,totalM/grainDensity,gradingCurveType)/2;
            mfs.gradingCurve(grainR*2);

            %determine the box size
            SET=mfs.getBoxSample(grainR,sampleW,sampleL,hRate);
            SET.moNum=moNum;%divided into 'moNum' size groups
            %------------------end set the grain size and box size------------------
            B=obj_Box;%build a box object
            B.name='BoxCompactionShock';
            B.GPUstatus='auto';
            B.setType('topPlaten');
            B.PexpandRate=2;
            B.uniformGRate=isUniformGRate;
            B.buildInitialModel(SET);%B.show();
            B.setUIoutput();
            B.resetStatusBeforeDrop=1;
            d=B.d;

            B.TAG.grainDensity=grainDensity;
            B.TAG.totalM=totalM;
            B.TAG.rangeNum=rangeNum;
            B.TAG.grainSizeDistribution=grainSizeDistribution;
            B.TAG.friction=friction;
            B.TAG.isCement=isCement;
            B.TAG.is2D=is2D;
            B.TAG.hRate=hRate;
            B.TAG.seedId=seedId;
            B.TAG.rate=rate;
            %--------------step1: end initializing Box model------------
            
            d.show('aR');
            app.Label_particleNumber.Text=['活动单元数为：' num2str(d.mo.mNum)];
            app.Box=B;
            app.DataCenter=d;
            app.Label_statusBar.Text='已完成初始建模';
            app.Button_gravitySedimentAndStandardBalance.Enable=true;
        end

        % Button pushed function: Button_showPSDcurve
        function Button_showPSDcurvePushed(app, event)
            seedId=app.EditField_seedID.Value;
            grainSizeDistribution=str2num(app.EditField_PSDmatrix.Value);
            rangeNum=app.EditField_rangeNumber.Value;
            
            fs.randSeed(seedId);
            grainSizeDistribution=grainSizeDistribution(end-rangeNum+1:end,:);
            totalM=app.EditField_totalM.Value;
            grainDensity=app.EditField_particleDensity.Value;
            grainRadius=mfs.getGradationDiameter(grainSizeDistribution,totalM/grainDensity,app.EditField_PSDtype.Value)/2;
            mfs.gradingCurve(2*grainRadius);
        end

        % Button pushed function: 
        % Button_gravitySedimentAndStandardBalance
        function Button_gravitySedimentAndStandardBalancePushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            B.resetStatusBeforeDrop=app.CheckBox_resetStatusBeforeDrop.Value;
            isCement=app.CheckBox_isCement.Value;
            rate=B.TAG.rate;
            friction=app.EditField_friction.Value;
            matTxt2=str2num(app.EditField_materialMatrix.Value);
            app.Button_gravitySedimentAndStandardBalance.Enable=false;
            app.Label_statusBar.Text='正在堆积建模中……';

            %--------------step2: set material------------
            Mats{1,1}=material('soil1',matTxt2,B.ballR);
            Mats{1,1}.Id=1;
            Mats{1,1}.setGrainDensity(B.TAG.grainDensity);
            d.Mats=Mats;
            d.groupMat2Model();
            d.breakGroup();
            if B.sampleL==0
                B.convert2D(B.ballR);%change ball properties to 2D
            end
            if friction>0
                d.mo.setShear('on');
                d.mo.aMUp(:)=friction;
                d.mo.aMUp(d.mNum+1:end)=0;
                d.aMUp=d.mo.aMUp;
            end
            d.showB=1;
            %--------------step2: end set material------------
            
            %--------------step3: gravitySediment------------
            B.gravitySediment(rate,isCement);%element will be cemented when ture
            d.balance('Standard');
            d.status.dispEnergy();%display the energy of the model
            d.setData();
            pZ=min(d.mo.aZ(d.GROUP.topPlaten))-B.ballR*5;
            porosity=mfs.getPorosity(B,pZ);

            d.show('aR');
            %return and save result--------------
            d.status.dispEnergy();%display the energy of the model
            d.mo.setGPU('off');
            d.clearData(1);%clear dependent data
            d.recordCalHour('Box1Finish');
            save(['TempModel/' B.name '1.mat'],'B','d','-v7.3');
            save(['TempModel/' B.name '-Seed' num2str(B.TAG.seedId) '-rangeNum' num2str(B.TAG.rangeNum) '-friction' num2str(B.TAG.friction) '-1R' num2str(B.ballR) 'aNum' num2str(d.aNum) '.mat'],'-v7.3');
            d.calculateData();%because data is clear, it will be re-calculated
            %--------------step3: end gravitySediment------------
            
            app.Button_gravitySedimentAndStandardBalance.Enable=true;
            app.Label_porosity.Text=['试样的孔隙率为：',num2str(porosity*100),'%'];
            app.Label_statusBar.Text='已完成堆积建模，数据文件保存于TempModel文件夹中';
            app.Box=B;
            app.DataCenter=d;
        end

        % Callback function
        function Button_saveModelPushed(app, event)

        end

        % Callback function
        function Button_PostProcessingModulePushed(app, event)

        end

        % Button pushed function: Button_loadModel
        function Button_loadModelPushed(app, event)
            load(['TempModel/',app.EditField_modelName2.Value,'1.mat']);
            
            %--------------step1: load data file------------
            B.setUIoutput();
            d=B.d;
            d.calculateData();
            d.mo.setGPU('off');
            d.getModel();%d.setModel();%reset the initial status of the model
            d.resetStatus();%initialize model status, which records running information
            d.setStandarddT();
            d.mo.dT=d.mo.dT*4;
            %--------------step1: end load data file------------
            
            d.show('aR');
            app.Button_startShock.Enable=true;
            app.Box=B;
            app.DataCenter=d;
        end

        % Button pushed function: Button_cutSample
        function Button_cutSamplePushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            cutHeight=app.EditField_cutHeight.Value;
            cutSample=1;    

            %--------------step2: cut model------------
            if cutSample==1
                [~,topId]=mfs.splitGroup(d,'sample','aZ',cutHeight);
                d.delElement(topId);
                topLimit=max(d.mo.aZ(d.GROUP.sample)+d.mo.aR(d.GROUP.sample));
                dZ=topLimit-min(d.mo.aZ(d.GROUP.topPlaten)-d.mo.aR(d.GROUP.topPlaten));
                d.moveGroup('topPlaten',0,0,dZ);
            end
            %--------------step2: end cut model------------

            d.show('aR');
            app.Box=B;
            app.DataCenter=d;
        end

        % Button pushed function: Button_showWaveCurve
        function Button_showWaveCurvePushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            staticPressure=app.EditField_staticPressure.Value;
            shockA=app.EditField_shockA.Value;
            shockM=(staticPressure*(B.sampleW*B.sampleL))/9.8;
            shockF=app.EditField_shockF.Value;
            totalSecond=app.EditField_totalSecond.Value;
            totalCircle=app.EditField_totalCircle.Value;
            isCompressiveWave=app.CheckBox_isCompressiveWave.Value;

            %--------------step3: set the shock curve------------
            [realTime,~]=d.balance('Time');%获得一次标准平衡的实际时间和总平衡次数
            standardRate=totalSecond/totalCircle/realTime;%每次循环中的标准平衡次数
            [realTime,balanceNum]=d.balance('Time',standardRate);
            totalBalanceNum=balanceNum*totalCircle;
            totalT=totalBalanceNum*d.mo.dT;%total time of the wave
            fs.disp(['total time is: ' num2str(totalT) ' seconds']);

            if B.is2D==1
                shockM=abs(staticPressure*B.ballR*2*B.sampleW/9.8);
            else
                shockM=abs(staticPressure*B.sampleL*B.sampleW/9.8);
            end
            tId=d.GROUP.topPlaten;
            shockPlatenFilter=(d.mo.aX(tId)>0)&(d.mo.aX(tId)<B.sampleW)&(d.mo.aY(tId)>0)&(d.mo.aY(tId)<B.sampleL);
            shockId=tId(shockPlatenFilter);
            d.addGroup('Shocker',shockId);
            vM=shockM/length(shockId);
            vGZ0=vM*-9.8;
            maxAddGZ=-vM*shockA*(2*pi*shockF)^2;
            d.mo.mM(shockId)=vM;

            dT2=1/shockF/20;
            if d.mo.dT>=dT2
                Ts=(0:totalBalanceNum)*d.mo.dT;
            else
                Ts=(0:ceil(totalBalanceNum*d.mo.dT/dT2))*dT2;
            end
            Values=vGZ0+maxAddGZ*sin((2*pi)*shockF*Ts);
            if isCompressiveWave==1
                Values(Values>0)=0;
            end
            figure;
            plot(Ts,Values);
            %--------------step3: end set the shock curve------------
        end

        % Button pushed function: Button_showReceiver
        function Button_showReceiverPushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            receiverNum=app.EditField_receiverNumber.Value;

            %--------------step4: set the wave receiver------------
            centerx=B.sampleW/2;%center position of the receiver
            centery=mean(d.mo.aY(d.GROUP.sample));
            centerz=mean(d.mo.aZ(d.GROUP.topPlaten))/(receiverNum-1);
            R=B.ballR*4;%radius of the receiver
            gNames={};
            prop1='mAZ';%record the property 1
            prop2='aZ';%record the property 2
            for i=1:receiverNum
                gName=['Receiver' num2str(i)];
                gNames=[gNames(:);gName];
                f.run('fun/defineSphereGroup.m',d,gName,centerx,centery,centerz*(i-1),R);
                d.addRecordProp(gName,prop1);%declare recording mAZ
                d.addRecordProp(gName,prop2);%declare recording mAZ
            end
            figure;
            d.setGroupId();
            d.showFilter('Group',gNames,'aR');
            title('振动信号接收器位置');
            %--------------step4: end set the wave receiver------------

            app.Box=B;
            app.DataCenter=d;
        end

        % Button pushed function: Button_startShock
        function Button_startShockPushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            
            staticPressure=app.EditField_staticPressure.Value;
            shockA=app.EditField_shockA.Value;
            shockF=app.EditField_shockF.Value;
            totalSecond=app.EditField_totalSecond.Value;
            totalCircle=app.EditField_totalCircle.Value;
            isCompressiveWave=app.CheckBox_isCompressiveWave.Value;
            isConnect=app.CheckBox_connectSample.Value;

            mVisRate=app.EditField_mVisrate.Value;
            aBFRate=app.EditField_aBFrate.Value;
            aFS0Rate=app.EditField_aFS0rate.Value;
            aMUpRate=app.EditField_aMUprate.Value;
            receiverNum=app.EditField_receiverNumber.Value;
            additionalStandardRate=app.EditField_additionalStandardRate.Value;
            prop1='mAZ';%record the property 1
            prop2='aZ';%record the property 2
            B.TAG.prop1=prop1;
            B.TAG.prop2=prop2;
            app.Button_startShock.Enable=false;
            app.Label_statusBar.Text='正在振动压实中……';
            

            %--------------step3: set the shock curve------------
            [realTime,~]=d.balance('Time');%获得一次标准平衡的实际时间和总平衡次数
            standardRate=totalSecond/totalCircle/realTime;%每次循环中的标准平衡次数
            [~,balanceNum]=d.balance('Time',standardRate);
            totalBalanceNum=balanceNum*totalCircle;
            totalT=totalBalanceNum*d.mo.dT;%total time of the wave
            fs.disp(['total time is: ' num2str(totalT) ' seconds']);

            if B.is2D==1
                shockM=abs(staticPressure*B.ballR*2*B.sampleW/9.8);
            else
                shockM=abs(staticPressure*B.sampleL*B.sampleW/9.8);
            end
            tId=d.GROUP.topPlaten;
            shockPlatenFilter=(d.mo.aX(tId)>0)&(d.mo.aX(tId)<B.sampleW)&(d.mo.aY(tId)>0)&(d.mo.aY(tId)<B.sampleL);
            shockId=tId(shockPlatenFilter);
            d.addGroup('Shocker',shockId);
            vM=shockM/length(shockId);
            vGZ0=vM*-9.8;
            maxAddGZ=-vM*shockA*(2*pi*shockF)^2;
            d.mo.mM(shockId)=vM;

            dT2=1/shockF/20;
            if d.mo.dT>=dT2
                Ts=(0:totalBalanceNum)*d.mo.dT;
            else
                Ts=(0:ceil(totalBalanceNum*d.mo.dT/dT2))*dT2;
            end
            Values=vGZ0+maxAddGZ*sin((2*pi)*shockF*Ts);
            if isCompressiveWave==1
                Values(Values>0)=0;
            end
            figure;
            plot(Ts,Values);
            %--------------step3: end set the shock curve------------

            %--------------step4: set the wave receiver------------
            centerx=B.sampleW/2;%center position of the receiver
            centery=mean(d.mo.aY(d.GROUP.sample));
            centerz=mean(d.mo.aZ(d.GROUP.topPlaten))/(receiverNum-1);
            R=B.ballR*4;%radius of the receiver
            gNames={};
            prop1='mAZ';%record the property 1
            prop2='aZ';%record the property 2
            for i=1:receiverNum
                gName=['Receiver' num2str(i)];
                gNames=[gNames(:);gName];
                f.run('fun/defineSphereGroup.m',d,gName,centerx,centery,centerz*(i-1),R);
                d.addRecordProp(gName,prop1);%declare recording mAZ
                d.addRecordProp(gName,prop1);%declare recording mAZ
                d.addRecordProp(gName,prop1);%declare recording mAZ
                d.addRecordProp(gName,prop2);%declare recording mAZ
            end
            figure;
            d.setGroupId();
            d.showFilter('Group',gNames,'aR');
            title('振动信号接收器位置');
            %--------------step4: end set the wave receiver------------

            %--------------step5: numerical simulation of compaction------------
            B.TAG.receiverNum=receiverNum;
            waveProp='mGZ';
            d.addTimeProp('Shocker',waveProp,Ts,Values);%assign the AZ to elements of LeftLine
            d.addRecordProp('Shocker',waveProp);%declare recording mAZ

            d.mo.setGPU('auto');
            gpuStatus=d.mo.setGPU('auto');
            if isConnect==1
                d.connectGroup();
                d.mo.zeroBalance();
                d.deleteConnection('boundary');
                d.balance('Standard',2);
            end
            d.mo.isHeat=1;%calculate heat in the model
            d.mo.mVis=d.mo.mVis*mVisRate;
            d.mo.aBF=d.mo.aBF*aBFRate;
            d.mo.aFS0=d.mo.aFS0*aFS0Rate;
            d.mo.aMUp=d.mo.aMUp*aMUpRate;

            d.tic(totalCircle);
            fName=['data/step/' B.name 'Seed' num2str(B.TAG.seedId) '-rangeNum' num2str(B.TAG.rangeNum) '-friction' num2str(B.TAG.friction) '-1R' num2str(B.ballR) 'aNum' num2str(d.aNum) 'P' num2str(staticPressure) 'A' num2str(shockA) 'F' num2str(shockF) 'loopNum'];
            d.figureNumber=1;

            d.status.TAG.B=B;
            pZ=min(d.mo.aZ(d.GROUP.topPlaten))-B.ballR*5;
            porosity=mfs.getPorosity(B,pZ);
            d.status.SET.shockPorosities=porosity;%initialize the value
            recordCommand='d=obj.dem;B=obj.TAG.B;pZ=min(d.mo.aZ(d.GROUP.topPlaten))-B.ballR*5;porosity=mfs.getPorosity(B,pZ);';
            d.status.recordCommand=[recordCommand 'd.status.SET.shockPorosities=[d.status.SET.shockPorosities;porosity];'];

            for i=1:totalCircle
                d.mo.setGPU(gpuStatus);
                d.balance('Standard',standardRate);

                d.setData();
                d.show('mVZ');
                d.clearData(1);
                save([fName num2str(i) '.mat']);
                d.calculateData();
                d.toc();%show the note of time
            end
            d.mo.mGZ(d.GROUP.topPlaten)=d.mo.mM(d.GROUP.topPlaten)*-9.8;
            d.mo.setGPU(gpuStatus);
            mVis0=d.mo.mVis;
            d.setStandardVis();
            d.balance('Standard',additionalStandardRate);
            d.mo.mVis=mVis0;
            d.mo.setGPU('off');

            %show the curves
            for i=1:receiverNum
                subplot(receiverNum,2,(receiverNum-i)*2+1);
                d.status.show(['PROPReceiver' num2str(i) '_' prop1]);
                subplot(receiverNum,2,(receiverNum-i)*2+2);
                d.status.show(['PROPReceiver' num2str(i) '_' prop2]);
            end

            figure;
            d.status.show(['PROPShocker_' waveProp]);
            title('上压力板Z方向加速度变化图');
            d.status.show('SETshockPorosities');
            title('孔隙率变化图');

            d.clearData(1);
            d.recordCalHour('Box2Finish');
            save(['TempModel/' B.name '2.mat'],'B','d','-v7.3');
            save(['TempModel/' B.name '2-Seed' num2str(B.TAG.seedId) '-rangeNum' num2str(B.TAG.rangeNum) '-friction' num2str(B.TAG.friction) '-1R' num2str(B.ballR) 'aNum' num2str(d.aNum) 'P' num2str(staticPressure) 'A' num2str(shockA) 'F' num2str(shockF) '.mat'],'-v7.3');
            d.calculateData();
            %--------------step5: end numerical simulation of compaction------------


            app.Button_startShock.Enable=true;
            app.Label_statusBar.Text='已完成振动压实，数据文件保存于TempModel文件夹中';
            app.Box=B;
            app.DataCenter=d;
        end

        % Callback function
        function Button_saveResultsPushed(app, event)

        end

        % Callback function
        function Button_PostProcessingModule2Pushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            d.showB=0;
            d.showFilter();
            PlottingAreaPosition=app.Settings.PlottingAreaPosition;
            app.Settings.PlottingAreaPosition=[];
            setappdata(0,'app',app);
            UI_PostProcess(d);
            app.Settings.PlottingAreaPosition=PlottingAreaPosition;
            setappdata(0,'app',app);
            app.Box=B;
            app.DataCenter=d;
        end

        % Button pushed function: Button_openDataFile
        function Button_openDataFilePushed(app, event)
            dataFileName=app.EditField_dataFile.Value;
            load(dataFileName);
            d.calculateData();
            app.Box=B;
            app.DataCenter=d;
        end

        % Button pushed function: Button
        function ButtonPushed(app, event)

            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            d.status.show('SETshockPorosities');
        end

        % Button pushed function: Button_2
        function Button_2Pushed(app, event)
            B=app.Box;
            d=app.DataCenter;
            if isempty(d)
                msgbox('请先生成或导入数据');
                return
            end
            figure;
            %show the curves
            receiverNum=B.TAG.receiverNum;
            prop1=B.TAG.prop1;
            prop2=B.TAG.prop2;
            for i=1:receiverNum
                subplot(receiverNum,2,(receiverNum-i)*2+1);
                d.status.show(['PROPReceiver' num2str(i) '_' prop1]);
                subplot(receiverNum,2,(receiverNum-i)*2+2);
                d.status.show(['PROPReceiver' num2str(i) '_' prop2]);
            end

        end

        % Callback function
        function Button_3Pushed(app, event)

        end

        % Callback function
        function Button_5Pushed(app, event)
            
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create WinMain and hide until all components are created
            app.WinMain = uifigure('Visible', 'off');
            app.WinMain.Colormap = [0.2431 0.149 0.6588;0.251 0.1647 0.7059;0.2588 0.1804 0.7529;0.2627 0.1961 0.7961;0.2706 0.2157 0.8353;0.2745 0.2353 0.8706;0.2784 0.2549 0.898;0.2784 0.2784 0.9216;0.2824 0.302 0.9412;0.2824 0.3216 0.9569;0.2784 0.3451 0.9725;0.2745 0.3686 0.9843;0.2706 0.3882 0.9922;0.2588 0.4118 0.9961;0.2431 0.4353 1;0.2196 0.4588 0.9961;0.1961 0.4863 0.9882;0.1843 0.5059 0.9804;0.1804 0.5294 0.9686;0.1765 0.549 0.9529;0.1686 0.5686 0.9373;0.1529 0.5922 0.9216;0.1451 0.6078 0.9098;0.1373 0.6275 0.898;0.1255 0.6471 0.8902;0.1098 0.6627 0.8745;0.0941 0.6784 0.8588;0.0706 0.6941 0.8392;0.0314 0.7098 0.8157;0.0039 0.7216 0.7922;0.0078 0.7294 0.7647;0.0431 0.7412 0.7412;0.098 0.749 0.7137;0.1412 0.7569 0.6824;0.1725 0.7686 0.6549;0.1922 0.7765 0.6235;0.2157 0.7843 0.5922;0.2471 0.7922 0.5569;0.2902 0.7961 0.5176;0.3412 0.8 0.4784;0.3922 0.8039 0.4353;0.4471 0.8039 0.3922;0.5059 0.8 0.349;0.5608 0.7961 0.3059;0.6157 0.7882 0.2627;0.6706 0.7804 0.2235;0.7255 0.7686 0.1922;0.7725 0.7608 0.1647;0.8196 0.749 0.1529;0.8627 0.7412 0.1608;0.902 0.7333 0.1765;0.9412 0.7294 0.2118;0.9725 0.7294 0.2392;0.9961 0.7451 0.2353;0.9961 0.7647 0.2196;0.9961 0.7882 0.2039;0.9882 0.8118 0.1882;0.9804 0.8392 0.1765;0.9686 0.8627 0.1647;0.9608 0.8902 0.1529;0.9608 0.9137 0.1412;0.9647 0.9373 0.1255;0.9686 0.9608 0.1059;0.9765 0.9843 0.0824];
            app.WinMain.Position = [100 100 1000 700];
            app.WinMain.Name = '砂土振动压实离散元仿真系统';
            app.WinMain.CloseRequestFcn = createCallbackFcn(app, @WinMainCloseRequest, true);

            % Create UIAxes_PlottingArea
            app.UIAxes_PlottingArea = uiaxes(app.WinMain);
            title(app.UIAxes_PlottingArea, '绘图区')
            xlabel(app.UIAxes_PlottingArea, 'X')
            ylabel(app.UIAxes_PlottingArea, 'Y')
            app.UIAxes_PlottingArea.Colormap = [0.2431 0.149 0.6588;0.251 0.1647 0.7059;0.2588 0.1804 0.7529;0.2627 0.1961 0.7961;0.2706 0.2157 0.8353;0.2745 0.2353 0.8706;0.2784 0.2549 0.898;0.2784 0.2784 0.9216;0.2824 0.302 0.9412;0.2824 0.3216 0.9569;0.2784 0.3451 0.9725;0.2745 0.3686 0.9843;0.2706 0.3882 0.9922;0.2588 0.4118 0.9961;0.2431 0.4353 1;0.2196 0.4588 0.9961;0.1961 0.4863 0.9882;0.1843 0.5059 0.9804;0.1804 0.5294 0.9686;0.1765 0.549 0.9529;0.1686 0.5686 0.9373;0.1529 0.5922 0.9216;0.1451 0.6078 0.9098;0.1373 0.6275 0.898;0.1255 0.6471 0.8902;0.1098 0.6627 0.8745;0.0941 0.6784 0.8588;0.0706 0.6941 0.8392;0.0314 0.7098 0.8157;0.0039 0.7216 0.7922;0.0078 0.7294 0.7647;0.0431 0.7412 0.7412;0.098 0.749 0.7137;0.1412 0.7569 0.6824;0.1725 0.7686 0.6549;0.1922 0.7765 0.6235;0.2157 0.7843 0.5922;0.2471 0.7922 0.5569;0.2902 0.7961 0.5176;0.3412 0.8 0.4784;0.3922 0.8039 0.4353;0.4471 0.8039 0.3922;0.5059 0.8 0.349;0.5608 0.7961 0.3059;0.6157 0.7882 0.2627;0.6706 0.7804 0.2235;0.7255 0.7686 0.1922;0.7725 0.7608 0.1647;0.8196 0.749 0.1529;0.8627 0.7412 0.1608;0.902 0.7333 0.1765;0.9412 0.7294 0.2118;0.9725 0.7294 0.2392;0.9961 0.7451 0.2353;0.9961 0.7647 0.2196;0.9961 0.7882 0.2039;0.9882 0.8118 0.1882;0.9804 0.8392 0.1765;0.9686 0.8627 0.1647;0.9608 0.8902 0.1529;0.9608 0.9137 0.1412;0.9647 0.9373 0.1255;0.9686 0.9608 0.1059;0.9765 0.9843 0.0824];
            app.UIAxes_PlottingArea.TitleFontWeight = 'bold';
            app.UIAxes_PlottingArea.Position = [581 381 400 300];

            % Create Steps
            app.Steps = uitabgroup(app.WinMain);
            app.Steps.Position = [21 101 540 580];

            % Create Home
            app.Home = uitab(app.Steps);
            app.Home.Title = '主页';

            % Create Image1
            app.Image1 = uiimage(app.Home);
            app.Image1.Position = [37 22 240 259];
            app.Image1.ImageSource = 'CompactionShock1.jpg';

            % Create V10Label
            app.V10Label = uilabel(app.Home);
            app.V10Label.FontName = '微软雅黑';
            app.V10Label.FontSize = 27;
            app.V10Label.FontWeight = 'bold';
            app.V10Label.Position = [24 425 425 110];
            app.V10Label.Text = {'砂土振动压实离散元仿真系统'; '版本：V1.0'};

            % Create Image2
            app.Image2 = uiimage(app.Home);
            app.Image2.Position = [329 31 144 242];
            app.Image2.ImageSource = 'CompactionShock3.jpg';

            % Create GIFLabel
            app.GIFLabel = uilabel(app.Home);
            app.GIFLabel.VerticalAlignment = 'top';
            app.GIFLabel.FontName = '微软雅黑';
            app.GIFLabel.FontSize = 14;
            app.GIFLabel.Position = [24 293 505 110];
            app.GIFLabel.Text = {'此软件基于离散元法，模拟特定级配砂土的振动压实过程，主要包括以下功能：'; '（1）堆积建模。根据设定的级配和砂土性质，自动堆积土样'; '（2）振动压实。根据设定的振动荷载和时间，压实土样，并记录信息'; '（3）数据处理。生成结果曲线、场图、GIF动画，以及二次开发'};

            % Create Step1
            app.Step1 = uitab(app.Steps);
            app.Step1.Title = '堆积建模';

            % Create Panel
            app.Panel = uipanel(app.Step1);
            app.Panel.Title = '初始建模';
            app.Panel.Position = [21 263 500 242];

            % Create Label_2
            app.Label_2 = uilabel(app.Panel);
            app.Label_2.HorizontalAlignment = 'right';
            app.Label_2.Position = [11 188 53 22];
            app.Label_2.Text = '随机种子';

            % Create EditField_seedID
            app.EditField_seedID = uieditfield(app.Panel, 'numeric');
            app.EditField_seedID.Limits = [1 99];
            app.EditField_seedID.Position = [100 188 56 22];
            app.EditField_seedID.Value = 1;

            % Create Button_buildInitialModel
            app.Button_buildInitialModel = uibutton(app.Panel, 'push');
            app.Button_buildInitialModel.ButtonPushedFcn = createCallbackFcn(app, @Button_buildInitialModelPushed, true);
            app.Button_buildInitialModel.Position = [278 16 209 24];
            app.Button_buildInitialModel.Text = '建立初始模型*';

            % Create Button_showPSDcurve
            app.Button_showPSDcurve = uibutton(app.Panel, 'push');
            app.Button_showPSDcurve.ButtonPushedFcn = createCallbackFcn(app, @Button_showPSDcurvePushed, true);
            app.Button_showPSDcurve.Position = [377 131 110 22];
            app.Button_showPSDcurve.Text = '显示级配曲线';

            % Create Label_3
            app.Label_3 = uilabel(app.Panel);
            app.Label_3.HorizontalAlignment = 'right';
            app.Label_3.Position = [11 128 65 22];
            app.Label_3.Text = '使用级配数';

            % Create EditField_rangeNumber
            app.EditField_rangeNumber = uieditfield(app.Panel, 'numeric');
            app.EditField_rangeNumber.Limits = [1 6];
            app.EditField_rangeNumber.Position = [100 128 56 22];
            app.EditField_rangeNumber.Value = 1;

            % Create Label_4
            app.Label_4 = uilabel(app.Panel);
            app.Label_4.HorizontalAlignment = 'right';
            app.Label_4.Position = [11 158 53 22];
            app.Label_4.Text = '级配矩阵';

            % Create EditField_PSDmatrix
            app.EditField_PSDmatrix = uieditfield(app.Panel, 'text');
            app.EditField_PSDmatrix.Position = [79 158 410 22];
            app.EditField_PSDmatrix.Value = '[1,5,15.5;5,10,19.4;10,20,27.06;20,40,4.5]*1e-3';

            % Create kgLabel
            app.kgLabel = uilabel(app.Panel);
            app.kgLabel.HorizontalAlignment = 'right';
            app.kgLabel.Position = [9 78 90 22];
            app.kgLabel.Text = '试样质量（kg）';

            % Create EditField_totalM
            app.EditField_totalM = uieditfield(app.Panel, 'numeric');
            app.EditField_totalM.Limits = [0 Inf];
            app.EditField_totalM.Position = [100 78 56 22];
            app.EditField_totalM.Value = 25;

            % Create kgm3Label
            app.kgm3Label = uilabel(app.Panel);
            app.kgm3Label.HorizontalAlignment = 'right';
            app.kgm3Label.Position = [160 78 116 22];
            app.kgm3Label.Text = '颗粒密度（kg/m^3）';

            % Create EditField_particleDensity
            app.EditField_particleDensity = uieditfield(app.Panel, 'numeric');
            app.EditField_particleDensity.Limits = [0 Inf];
            app.EditField_particleDensity.Position = [276 78 56 22];
            app.EditField_particleDensity.Value = 2652.8;

            % Create mLabel
            app.mLabel = uilabel(app.Panel);
            app.mLabel.HorizontalAlignment = 'right';
            app.mLabel.Position = [9 48 87 22];
            app.mLabel.Text = '试样宽度（m）';

            % Create EditField_sampleW
            app.EditField_sampleW = uieditfield(app.Panel, 'numeric');
            app.EditField_sampleW.Limits = [0 Inf];
            app.EditField_sampleW.Position = [100 48 56 22];
            app.EditField_sampleW.Value = 0.2;

            % Create mLabel_2
            app.mLabel_2 = uilabel(app.Panel);
            app.mLabel_2.HorizontalAlignment = 'right';
            app.mLabel_2.Position = [179 48 87 22];
            app.mLabel_2.Text = '试样长度（m）';

            % Create EditField_sampleL
            app.EditField_sampleL = uieditfield(app.Panel, 'numeric');
            app.EditField_sampleL.Limits = [0 Inf];
            app.EditField_sampleL.Position = [276 48 55 22];
            app.EditField_sampleL.Value = 0.2;

            % Create Label_5
            app.Label_5 = uilabel(app.Panel);
            app.Label_5.HorizontalAlignment = 'right';
            app.Label_5.Position = [346 48 77 22];
            app.Label_5.Text = '试样高度比率';

            % Create EditField_sampleHrate0
            app.EditField_sampleHrate0 = uieditfield(app.Panel, 'numeric');
            app.EditField_sampleHrate0.Limits = [1 Inf];
            app.EditField_sampleHrate0.Position = [430 48 56 22];
            app.EditField_sampleHrate0.Value = 1;

            % Create Label_7
            app.Label_7 = uilabel(app.Panel);
            app.Label_7.HorizontalAlignment = 'right';
            app.Label_7.Position = [208 131 53 22];
            app.Label_7.Text = '级配类型';

            % Create EditField_PSDtype
            app.EditField_PSDtype = uieditfield(app.Panel, 'numeric');
            app.EditField_PSDtype.Limits = [-1 Inf];
            app.EditField_PSDtype.Position = [277 131 55 22];
            app.EditField_PSDtype.Value = -1;

            % Create Label_particleNumber
            app.Label_particleNumber = uilabel(app.Panel);
            app.Label_particleNumber.Position = [271 190 220 22];
            app.Label_particleNumber.Text = '活动单元数为：';

            % Create Panel_2
            app.Panel_2 = uipanel(app.Step1);
            app.Panel_2.Title = '材料设置';
            app.Panel_2.Position = [20 145 500 110];

            % Create Label_8
            app.Label_8 = uilabel(app.Panel_2);
            app.Label_8.HorizontalAlignment = 'right';
            app.Label_8.Position = [11 56 53 22];
            app.Label_8.Text = '材料矩阵';

            % Create EditField_materialMatrix
            app.EditField_materialMatrix = uieditfield(app.Panel_2, 'text');
            app.EditField_materialMatrix.Tooltip = {'[杨氏模量,泊松比,抗拉强度,抗压强度,内摩擦角]'};
            app.EditField_materialMatrix.Position = [79 56 193 22];
            app.EditField_materialMatrix.Value = '[5e6,0.1,5e3,50e3,0.8,1650]';

            % Create Label_6
            app.Label_6 = uilabel(app.Panel_2);
            app.Label_6.HorizontalAlignment = 'right';
            app.Label_6.Position = [281 56 77 22];
            app.Label_6.Text = '颗粒摩擦系数';

            % Create EditField_friction
            app.EditField_friction = uieditfield(app.Panel_2, 'numeric');
            app.EditField_friction.Limits = [0 Inf];
            app.EditField_friction.Position = [373 56 80 22];
            app.EditField_friction.Value = 0.35;

            % Create Label_22
            app.Label_22 = uilabel(app.Panel_2);
            app.Label_22.Position = [15 11 482 32];
            app.Label_22.Text = {'注：材料矩阵参数依次为砂样杨氏模量、泊松比、抗拉强度、抗拉强度、摩擦系数、密度'; '其中砂样摩擦系数和密度不起作用，会被“颗粒密度”和“颗粒摩擦系数”的值代替'};

            % Create Panel_3
            app.Panel_3 = uipanel(app.Step1);
            app.Panel_3.Title = '堆积建模';
            app.Panel_3.Position = [20 13 500 122];

            % Create CheckBox_resetStatusBeforeDrop
            app.CheckBox_resetStatusBeforeDrop = uicheckbox(app.Panel_3);
            app.CheckBox_resetStatusBeforeDrop.Text = '在堆积之前重置状态记录';
            app.CheckBox_resetStatusBeforeDrop.Position = [11 68 180 22];
            app.CheckBox_resetStatusBeforeDrop.Value = true;

            % Create CheckBox_uniformGRate
            app.CheckBox_uniformGRate = uicheckbox(app.Panel_3);
            app.CheckBox_uniformGRate.Text = '使用统一的重力加速度';
            app.CheckBox_uniformGRate.Position = [211 68 180 22];
            app.CheckBox_uniformGRate.Value = true;

            % Create CheckBox_isCement
            app.CheckBox_isCement = uicheckbox(app.Panel_3);
            app.CheckBox_isCement.Text = '颗粒粘结';
            app.CheckBox_isCement.Position = [411 68 80 22];

            % Create Button_gravitySedimentAndStandardBalance
            app.Button_gravitySedimentAndStandardBalance = uibutton(app.Panel_3, 'push');
            app.Button_gravitySedimentAndStandardBalance.ButtonPushedFcn = createCallbackFcn(app, @Button_gravitySedimentAndStandardBalancePushed, true);
            app.Button_gravitySedimentAndStandardBalance.Position = [280 9 211 24];
            app.Button_gravitySedimentAndStandardBalance.Text = '开始堆积*';

            % Create Label_porosity
            app.Label_porosity = uilabel(app.Panel_3);
            app.Label_porosity.Position = [13 39 268 22];
            app.Label_porosity.Text = '试样的孔隙率为：';

            % Create Label_10
            app.Label_10 = uilabel(app.Step1);
            app.Label_10.HorizontalAlignment = 'right';
            app.Label_10.Position = [23 519 41 22];
            app.Label_10.Text = '模型名';

            % Create EditField_modelName
            app.EditField_modelName = uieditfield(app.Step1, 'text');
            app.EditField_modelName.Position = [79 519 183 22];
            app.EditField_modelName.Value = 'BoxCompactionShock';

            % Create Step2
            app.Step2 = uitab(app.Steps);
            app.Step2.Title = '振动压实';

            % Create Label_11
            app.Label_11 = uilabel(app.Step2);
            app.Label_11.HorizontalAlignment = 'right';
            app.Label_11.Position = [21 513 41 22];
            app.Label_11.Text = '模型名';

            % Create EditField_modelName2
            app.EditField_modelName2 = uieditfield(app.Step2, 'text');
            app.EditField_modelName2.Position = [77 513 208 22];
            app.EditField_modelName2.Value = 'BoxCompactionShock';

            % Create Button_loadModel
            app.Button_loadModel = uibutton(app.Step2, 'push');
            app.Button_loadModel.ButtonPushedFcn = createCallbackFcn(app, @Button_loadModelPushed, true);
            app.Button_loadModel.Position = [301 511 211 24];
            app.Button_loadModel.Text = '导入模型*';

            % Create Panel_4
            app.Panel_4 = uipanel(app.Step2);
            app.Panel_4.Title = '切割试样（可选）';
            app.Panel_4.Position = [21 435 500 70];

            % Create mLabel_3
            app.mLabel_3 = uilabel(app.Panel_4);
            app.mLabel_3.HorizontalAlignment = 'right';
            app.mLabel_3.Position = [11 16 87 22];
            app.mLabel_3.Text = '切割高度（m）';

            % Create EditField_cutHeight
            app.EditField_cutHeight = uieditfield(app.Panel_4, 'numeric');
            app.EditField_cutHeight.Limits = [0 Inf];
            app.EditField_cutHeight.Position = [106 16 103 22];
            app.EditField_cutHeight.Value = 0.34;

            % Create Button_cutSample
            app.Button_cutSample = uibutton(app.Panel_4, 'push');
            app.Button_cutSample.ButtonPushedFcn = createCallbackFcn(app, @Button_cutSamplePushed, true);
            app.Button_cutSample.Position = [280 16 209 22];
            app.Button_cutSample.Text = '切割模型';

            % Create Panel_5
            app.Panel_5 = uipanel(app.Step2);
            app.Panel_5.Title = '振动参数设置';
            app.Panel_5.Position = [21 272 500 153];

            % Create CheckBox_isCompressiveWave
            app.CheckBox_isCompressiveWave = uicheckbox(app.Panel_5);
            app.CheckBox_isCompressiveWave.Text = '是否仅有压缩波';
            app.CheckBox_isCompressiveWave.Position = [241 99 110 22];

            % Create Button_showWaveCurve
            app.Button_showWaveCurve = uibutton(app.Panel_5, 'push');
            app.Button_showWaveCurve.ButtonPushedFcn = createCallbackFcn(app, @Button_showWaveCurvePushed, true);
            app.Button_showWaveCurve.Position = [280 5 210 24];
            app.Button_showWaveCurve.Text = '显示振动曲线';

            % Create PaLabel
            app.PaLabel = uilabel(app.Panel_5);
            app.PaLabel.HorizontalAlignment = 'right';
            app.PaLabel.Position = [11 99 80 22];
            app.PaLabel.Text = '静压力（Pa）';

            % Create EditField_staticPressure
            app.EditField_staticPressure = uieditfield(app.Panel_5, 'numeric');
            app.EditField_staticPressure.Limits = [0 Inf];
            app.EditField_staticPressure.Position = [106 99 103 22];
            app.EditField_staticPressure.Value = 14370;

            % Create mLabel_4
            app.mLabel_4 = uilabel(app.Panel_5);
            app.mLabel_4.HorizontalAlignment = 'right';
            app.mLabel_4.Position = [11 69 63 22];
            app.mLabel_4.Text = '振幅（m）';

            % Create EditField_shockA
            app.EditField_shockA = uieditfield(app.Panel_5, 'numeric');
            app.EditField_shockA.Limits = [0 Inf];
            app.EditField_shockA.Position = [106 69 103 22];
            app.EditField_shockA.Value = 0.001;

            % Create HzLabel
            app.HzLabel = uilabel(app.Panel_5);
            app.HzLabel.HorizontalAlignment = 'right';
            app.HzLabel.Position = [241 69 92 22];
            app.HzLabel.Text = '振动频率（Hz）';

            % Create EditField_shockF
            app.EditField_shockF = uieditfield(app.Panel_5, 'numeric');
            app.EditField_shockF.Limits = [0 Inf];
            app.EditField_shockF.Position = [348 69 103 22];
            app.EditField_shockF.Value = 35;

            % Create sLabel
            app.sLabel = uilabel(app.Panel_5);
            app.sLabel.HorizontalAlignment = 'right';
            app.sLabel.Position = [11 39 83 22];
            app.sLabel.Text = '振动时长（s）';

            % Create EditField_totalSecond
            app.EditField_totalSecond = uieditfield(app.Panel_5, 'numeric');
            app.EditField_totalSecond.Limits = [0 Inf];
            app.EditField_totalSecond.Position = [106 39 103 22];
            app.EditField_totalSecond.Value = 1;

            % Create Label_12
            app.Label_12 = uilabel(app.Panel_5);
            app.Label_12.HorizontalAlignment = 'right';
            app.Label_12.Position = [244 39 77 22];
            app.Label_12.Text = '中间文件个数';

            % Create EditField_totalCircle
            app.EditField_totalCircle = uieditfield(app.Panel_5, 'numeric');
            app.EditField_totalCircle.Limits = [0 Inf];
            app.EditField_totalCircle.Position = [348 39 103 22];
            app.EditField_totalCircle.Value = 10;

            % Create Panel_6
            app.Panel_6 = uipanel(app.Step2);
            app.Panel_6.Title = '设置接收器';
            app.Panel_6.Position = [22 194 500 70];

            % Create Label_17
            app.Label_17 = uilabel(app.Panel_6);
            app.Label_17.HorizontalAlignment = 'right';
            app.Label_17.Position = [15 15 65 22];
            app.Label_17.Text = '接收器数量';

            % Create EditField_receiverNumber
            app.EditField_receiverNumber = uieditfield(app.Panel_6, 'numeric');
            app.EditField_receiverNumber.Limits = [0 Inf];
            app.EditField_receiverNumber.Position = [105 16 103 22];
            app.EditField_receiverNumber.Value = 3;

            % Create Button_showReceiver
            app.Button_showReceiver = uibutton(app.Panel_6, 'push');
            app.Button_showReceiver.ButtonPushedFcn = createCallbackFcn(app, @Button_showReceiverPushed, true);
            app.Button_showReceiver.Position = [279 14 211 24];
            app.Button_showReceiver.Text = '显示振动信号接收器';

            % Create Panel_7
            app.Panel_7 = uipanel(app.Step2);
            app.Panel_7.Title = '振动压实';
            app.Panel_7.Position = [21 17 501 171];

            % Create Label_15
            app.Label_15 = uilabel(app.Panel_7);
            app.Label_15.HorizontalAlignment = 'right';
            app.Label_15.Position = [12 53 77 22];
            app.Label_15.Text = '摩擦系数倍率';

            % Create EditField_aMUprate
            app.EditField_aMUprate = uieditfield(app.Panel_7, 'numeric');
            app.EditField_aMUprate.Limits = [0 Inf];
            app.EditField_aMUprate.Position = [106 53 103 22];
            app.EditField_aMUprate.Value = 1;

            % Create Label_16
            app.Label_16 = uilabel(app.Panel_7);
            app.Label_16.HorizontalAlignment = 'right';
            app.Label_16.Position = [11 116 77 22];
            app.Label_16.Text = '阻尼系数倍率';

            % Create EditField_mVisrate
            app.EditField_mVisrate = uieditfield(app.Panel_7, 'numeric');
            app.EditField_mVisrate.Limits = [0 Inf];
            app.EditField_mVisrate.Position = [106 117 103 22];
            app.EditField_mVisrate.Value = 0.01;

            % Create Button_startShock
            app.Button_startShock = uibutton(app.Panel_7, 'push');
            app.Button_startShock.ButtonPushedFcn = createCallbackFcn(app, @Button_startShockPushed, true);
            app.Button_startShock.Position = [279 19 211 24];
            app.Button_startShock.Text = '开始压实*';

            % Create CheckBox_connectSample
            app.CheckBox_connectSample = uicheckbox(app.Panel_7);
            app.CheckBox_connectSample.Text = '胶结试样';
            app.CheckBox_connectSample.Position = [241 116 70 22];

            % Create Label_13
            app.Label_13 = uilabel(app.Panel_7);
            app.Label_13.HorizontalAlignment = 'right';
            app.Label_13.Position = [12 85 65 22];
            app.Label_13.Text = '断裂力倍率';

            % Create EditField_aBFrate
            app.EditField_aBFrate = uieditfield(app.Panel_7, 'numeric');
            app.EditField_aBFrate.Limits = [0 Inf];
            app.EditField_aBFrate.Position = [106 85 103 22];
            app.EditField_aBFrate.Value = 1;

            % Create Label_14
            app.Label_14 = uilabel(app.Panel_7);
            app.Label_14.HorizontalAlignment = 'right';
            app.Label_14.Position = [239 85 89 22];
            app.Label_14.Text = '初始抗剪力倍率';

            % Create EditField_aFS0rate
            app.EditField_aFS0rate = uieditfield(app.Panel_7, 'numeric');
            app.EditField_aFS0rate.Limits = [0 Inf];
            app.EditField_aFS0rate.Position = [346 85 103 22];
            app.EditField_aFS0rate.Value = 1;

            % Create Label_21
            app.Label_21 = uilabel(app.Panel_7);
            app.Label_21.HorizontalAlignment = 'right';
            app.Label_21.Position = [12 20 89 22];
            app.Label_21.Text = '压实后额外平衡';

            % Create EditField_additionalStandardRate
            app.EditField_additionalStandardRate = uieditfield(app.Panel_7, 'numeric');
            app.EditField_additionalStandardRate.Limits = [0 Inf];
            app.EditField_additionalStandardRate.Position = [106 20 103 22];
            app.EditField_additionalStandardRate.Value = 5;

            % Create dataCenter
            app.dataCenter = uitab(app.Steps);
            app.dataCenter.Title = '数据处理';

            % Create Label_20
            app.Label_20 = uilabel(app.dataCenter);
            app.Label_20.HorizontalAlignment = 'right';
            app.Label_20.Position = [21 513 53 22];
            app.Label_20.Text = '数据文件';

            % Create EditField_dataFile
            app.EditField_dataFile = uieditfield(app.dataCenter, 'text');
            app.EditField_dataFile.Position = [89 513 311 22];
            app.EditField_dataFile.Value = 'TempModel/BoxCompactionShock2.mat';

            % Create Button_openDataFile
            app.Button_openDataFile = uibutton(app.dataCenter, 'push');
            app.Button_openDataFile.ButtonPushedFcn = createCallbackFcn(app, @Button_openDataFilePushed, true);
            app.Button_openDataFile.Position = [411 513 110 22];
            app.Button_openDataFile.Text = '打开数据文件';

            % Create Button
            app.Button = uibutton(app.dataCenter, 'push');
            app.Button.ButtonPushedFcn = createCallbackFcn(app, @ButtonPushed, true);
            app.Button.Position = [21 465 240 30];
            app.Button.Text = '孔隙率-时间变化曲线';

            % Create Button_2
            app.Button_2 = uibutton(app.dataCenter, 'push');
            app.Button_2.ButtonPushedFcn = createCallbackFcn(app, @Button_2Pushed, true);
            app.Button_2.Position = [22 424 240 30];
            app.Button_2.Text = '接收器记录曲线';

            % Create GIFLabel_2
            app.GIFLabel_2 = uilabel(app.dataCenter);
            app.GIFLabel_2.Position = [24 300 497 74];
            app.GIFLabel_2.Text = {'提示：'; '（1）在菜单中选择“导出到主程序”，可查看模拟结果的详细数据，并进行高级数据处理'; '（2）在菜单中选择“后处理模块”，可在后处理中生成和保存各类图件和GIF动画'};

            % Create Tab
            app.Tab = uitab(app.Steps);
            app.Tab.Title = '关于';

            % Create MatDEMforummatdemcomhttpmatdemcomLabel
            app.MatDEMforummatdemcomhttpmatdemcomLabel = uilabel(app.Tab);
            app.MatDEMforummatdemcomhttpmatdemcomLabel.Position = [18 472 510 74];
            app.MatDEMforummatdemcomhttpmatdemcomLabel.Text = {'此软件基于国产高性能离散元仿真平台MatDEM定制，技术支持请联系：forum@matdem.com'; '更多信息请访问http://matdem.com'};

            % Create Label
            app.Label = uilabel(app.WinMain);
            app.Label.HorizontalAlignment = 'right';
            app.Label.Position = [581 339 41 22];
            app.Label.Text = '命令行';

            % Create EditField_CommandLine
            app.EditField_CommandLine = uieditfield(app.WinMain, 'text');
            app.EditField_CommandLine.Position = [637 339 284 22];

            % Create Button_Run
            app.Button_Run = uibutton(app.WinMain, 'push');
            app.Button_Run.ButtonPushedFcn = createCallbackFcn(app, @Button_RunPushed, true);
            app.Button_Run.Position = [931 339 50 22];
            app.Button_Run.Text = '运行';

            % Create TextArea_Message
            app.TextArea_Message = uitextarea(app.WinMain);
            app.TextArea_Message.Editable = 'off';
            app.TextArea_Message.Position = [581 21 400 300];

            % Create Label_statusBar
            app.Label_statusBar = uilabel(app.WinMain);
            app.Label_statusBar.BackgroundColor = [1 1 1];
            app.Label_statusBar.VerticalAlignment = 'top';
            app.Label_statusBar.WordWrap = 'on';
            app.Label_statusBar.FontSize = 14;
            app.Label_statusBar.Position = [21 21 540 60];
            app.Label_statusBar.Text = '准备就绪，带*号为必选操作，以“显示”开头的操作不是必须的';

            % Show the figure after all components are created
            app.WinMain.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = UI_CompactionShock_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.WinMain)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.WinMain)
        end
    end
end